//go:build android
// +build android

package main

import (
	"image/color"
	"strings"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
)

type field int

const (
	fieldNone field = iota
	fieldHost
	fieldPort
	fieldPassword
)

type RCONSetupUI struct {
	Host     string
	Port     string
	Password string

	focused   field
	Submitted bool
	Error     string

	ShouldOpenSettings bool
}

func NewRCONSetupUI() *RCONSetupUI {
	return &RCONSetupUI{}
}

func (u *RCONSetupUI) Update() {
	// Handle tap to focus fields / buttons
	if inpututil.IsMouseButtonJustPressed(ebiten.MouseButtonLeft) {
		x, y := ebiten.CursorPosition()

		// Field hitboxes
		if hit(x, y, 80, 180, 560, 70) {
			u.focus(fieldHost)
			return
		}
		if hit(x, y, 80, 300, 560, 70) {
			u.focus(fieldPort)
			return
		}
		if hit(x, y, 80, 420, 560, 70) {
			u.focus(fieldPassword)
			return
		}

		// Save button
		if hit(x, y, 80, 540, 260, 80) {
			u.Error = ""
			u.Submitted = true
			u.blur()
			return
		}

		// Clear button
		if hit(x, y, 380, 540, 260, 80) {
			u.Host = ""
			u.Port = ""
			u.Password = ""
			u.Error = ""
			u.Submitted = false
			u.focus(fieldHost)
			return
		}

		// Tap outside -> blur
		u.blur()
	}

	// Text input
	if u.focused != fieldNone {
		var chars []rune
		chars = ebiten.AppendInputChars(chars)
		if len(chars) > 0 {
			for _, r := range chars {
				// Filter newlines and weird control chars
				if r == '\n' || r == '\r' || r == '\t' {
					continue
				}
				u.addChar(r)
			}
		}

		// Backspace (repeat-friendly)
		if inpututil.IsKeyJustPressed(ebiten.KeyBackspace) || inpututil.IsKeyJustPressed(ebiten.KeyDelete) {
			u.backspace()
		}
	}
}

func (u *RCONSetupUI) Draw(screen *ebiten.Image) {
	w, h := screen.Size()
	_ = w
	_ = h

	// Background
	ebitenutil.DrawRect(screen, 0, 0, float64(w), float64(h), color.RGBA{15, 15, 18, 255})

	ebitenutil.DebugPrintAt(screen, "RCON Setup", 80, 90)
	ebitenutil.DebugPrintAt(screen, "Tap a field to type. Password is visible (as requested).", 80, 120)

	// Fields
	drawField(screen, 80, 180, 560, 70, "Host", u.Host, u.focused == fieldHost)
	drawField(screen, 80, 300, 560, 70, "Port", u.Port, u.focused == fieldPort)
	drawField(screen, 80, 420, 560, 70, "Password", u.Password, u.focused == fieldPassword)

	// Buttons
	drawButton(screen, 80, 540, 260, 80, "Save & Connect")
	drawButton(screen, 380, 540, 260, 80, "Clear")

	if u.Error != "" {
		ebitenutil.DebugPrintAt(screen, "Error: "+u.Error, 80, 650)
	}
}

func (u *RCONSetupUI) focus(f field) {
	u.focused = f
	ebiten.StartTextInput()
}

func (u *RCONSetupUI) blur() {
	u.focused = fieldNone
	ebiten.StopTextInput()
}

func (u *RCONSetupUI) addChar(r rune) {
	// Basic limit
	if len(u.current()) >= 128 {
		return
	}

	// Disallow spaces in host/port
	if u.focused == fieldHost || u.focused == fieldPort {
		if r == ' ' {
			return
		}
	}
	// Port digits only
	if u.focused == fieldPort {
		if r < '0' || r > '9' {
			return
		}
	}

	cur := u.current() + string(r)
	u.setCurrent(cur)
}

func (u *RCONSetupUI) backspace() {
	r := []rune(u.current())
	if len(r) == 0 {
		return
	}
	u.setCurrent(string(r[:len(r)-1]))
}

func (u *RCONSetupUI) current() string {
	switch u.focused {
	case fieldHost:
		return u.Host
	case fieldPort:
		return u.Port
	case fieldPassword:
		return u.Password
	default:
		return ""
	}
}

func (u *RCONSetupUI) setCurrent(v string) {
	switch u.focused {
	case fieldHost:
		u.Host = v
	case fieldPort:
		u.Port = v
	case fieldPassword:
		u.Password = v
	}
}

func hit(x, y, bx, by, bw, bh int) bool {
	return x >= bx && x < bx+bw && y >= by && y < by+bh
}

func drawField(screen *ebiten.Image, x, y, w, h int, label, value string, focused bool) {
	bg := color.RGBA{30, 30, 35, 230}
	if focused {
		bg = color.RGBA{50, 50, 70, 240}
	}
	ebitenutil.DrawRect(screen, float64(x), float64(y), float64(w), float64(h), bg)
	ebitenutil.DebugPrintAt(screen, label+": "+value, x+14, y+26)
}

func drawButton(screen *ebiten.Image, x, y, w, h int, label string) {
	ebitenutil.DrawRect(screen, float64(x), float64(y), float64(w), float64(h), color.RGBA{0, 0, 0, 160})
	ebitenutil.DebugPrintAt(screen, label, x+14, y+28)
}
