//go:build android
// +build android

package main

import (
	"fmt"
	"image"
	"image/color"
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	"github.com/hajimehoshi/ebiten/v2/inpututil"

	"github.com/zMoooooritz/go-let-loose/pkg/logger"
	"github.com/zMoooooritz/go-let-observer/pkg/ui"
	"github.com/zMoooooritz/go-let-observer/pkg/ui/shared"
	"github.com/zMoooooritz/go-let-observer/pkg/util"
)

type appMode int

const (
	modeSetup appMode = iota
	modeViewer
)

type AndroidApp struct {
	mode appMode

	setup *RCONSetupUI
	ui    ebiten.Game
}

func NewAndroidApp() ebiten.Game {
	logger.DefaultLogger()

	// Load default config first (so UI options exist even before creds are set).
	_ = util.InitConfig("")

	// Load saved RCON credentials, if any.
	creds, err := LoadSavedRCON()
	if err == nil && creds != nil && creds.Host != "" && creds.Port != "" {
		util.Config.ServerCredentials.Host = creds.Host
		util.Config.ServerCredentials.Port = creds.Port
		util.Config.ServerCredentials.Password = creds.Password
		return newViewerGame()
	}

	return &AndroidApp{
		mode:  modeSetup,
		setup: NewRCONSetupUI(),
	}
}

func newViewerGame() ebiten.Game {
	viewerMode := shared.MODE_VIEWER

	screenSize := util.Config.UIOptions.ScreenSize
	screenSize = util.Clamp(screenSize, shared.MIN_SCREEN_SIZE, shared.MAX_SCREEN_SIZE)
	util.Config.UIOptions.ScreenSize = screenSize

	util.InitializeFonts(screenSize)

	return ui.NewUI(viewerMode)
}

func (a *AndroidApp) Update() error {
	switch a.mode {
	case modeSetup:
		a.setup.Update()

		if a.setup.Submitted {
			// Validate minimal inputs
			host := a.setup.Host
			port := a.setup.Port
			pass := a.setup.Password

			// Basic sanity check
			if host == "" || port == "" {
				a.setup.Error = "Host and port are required"
				a.setup.Submitted = false
				return nil
			}

			// If port is not numeric, still allow (some people put "8010")
			if _, err := strconv.Atoi(port); err != nil {
				a.setup.Error = "Port must be a number"
				a.setup.Submitted = false
				return nil
			}

			// Save to private app storage
			err := SaveRCON(&SavedRCON{Host: host, Port: port, Password: pass})
			if err != nil {
				a.setup.Error = fmt.Sprintf("Save failed: %v", err)
				a.setup.Submitted = false
				return nil
			}

			// Apply into runtime config
			util.Config.ServerCredentials.Host = host
			util.Config.ServerCredentials.Port = port
			util.Config.ServerCredentials.Password = pass

			// Switch to viewer mode
			a.ui = newViewerGame()
			a.mode = modeViewer
			a.setup.Submitted = false
		}
		return nil

	case modeViewer:
		// Long-press (or tap) top-left "Settings" button to return to setup
		if a.setup != nil && a.setup.ShouldOpenSettings {
			// reset flag
			a.setup.ShouldOpenSettings = false
			a.mode = modeSetup
			return nil
		}

		// Allow opening settings overlay with a small tap-zone (top-left)
		if inpututil.IsMouseButtonJustPressed(ebiten.MouseButtonLeft) {
			x, y := ebiten.CursorPosition()
			if x >= 10 && x <= 170 && y >= 10 && y <= 60 {
				// go back to setup screen (fields prefilled)
				prefill := &SavedRCON{
					Host:     util.Config.ServerCredentials.Host,
					Port:     util.Config.ServerCredentials.Port,
					Password: util.Config.ServerCredentials.Password,
				}
				a.setup = NewRCONSetupUI()
				a.setup.Host = prefill.Host
				a.setup.Port = prefill.Port
				a.setup.Password = prefill.Password
				a.mode = modeSetup
				return nil
			}
		}

		return a.ui.Update()
	}
	return nil
}

func (a *AndroidApp) Draw(screen *ebiten.Image) {
	switch a.mode {
	case modeSetup:
		a.setup.Draw(screen)
	case modeViewer:
		a.ui.Draw(screen)

		// Draw a small Settings button overlay (tap to edit RCON)
		ebitenutil.DrawRect(screen, 10, 10, 160, 50, color.RGBA{0, 0, 0, 140})
		ebitenutil.DebugPrintAt(screen, "Settings", 20, 28)
	}
}

func (a *AndroidApp) Layout(outsideW, outsideH int) (int, int) {
	if a.mode == modeViewer && a.ui != nil {
		return a.ui.Layout(outsideW, outsideH)
	}
	return outsideW, outsideH
}
