//go:build android
// +build android

package main

import (
	"encoding/json"
	"os"
	"path/filepath"
)

type SavedRCON struct {
	Host     string `json:"host"`
	Port     string `json:"port"`
	Password string `json:"password"`
}

func rconConfigPath() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	// App-private on Android.
	return filepath.Join(dir, "go-let-observer", "rcon.json"), nil
}

func LoadSavedRCON() (*SavedRCON, error) {
	p, err := rconConfigPath()
	if err != nil {
		return nil, err
	}
	b, err := os.ReadFile(p)
	if err != nil {
		return nil, err
	}
	var cfg SavedRCON
	if err := json.Unmarshal(b, &cfg); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func SaveRCON(cfg *SavedRCON) error {
	p, err := rconConfigPath()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(p), 0o700); err != nil {
		return err
	}
	b, err := json.Marshal(cfg)
	if err != nil {
		return err
	}
	return os.WriteFile(p, b, 0o600)
}
